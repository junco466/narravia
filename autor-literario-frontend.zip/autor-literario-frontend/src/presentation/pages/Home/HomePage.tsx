import { Link } from 'react-router-dom';
import { usePosts } from '@/presentation/hooks/usePosts';
import { LoadingState } from '@/presentation/components/LoadingState/LoadingState';
import { ErrorState } from '@/presentation/components/ErrorState/ErrorState';
import { ContentList } from '@/presentation/components/ContentList/ContentList';
import { PostCard } from '@/presentation/components/PostCard/PostCard';
import styles from '@/presentation/pages/Home/HomePage.module.css';

export const HomePage = () => {
  const { data: posts, loading, error, reload } = usePosts();

  if (loading) {
    return <LoadingState label="Preparando la biblioteca..." />;
  }

  if (error) {
    return <ErrorState description={error} onRetry={reload} />;
  }

  const featured = posts?.slice(0, 3) ?? [];

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.copy}>
          <p className={styles.eyebrow}>Literatura contemporánea</p>
          <h1 className={styles.title}>Un frontend donde el texto respira antes que la interfaz.</h1>
          <p className={styles.description}>
            Poemas, novelas y reflexiones con una arquitectura preparada para crecer desde archivos Markdown
            hacia una API o un CMS sin reescribir la capa de presentación.
          </p>
          <div className={styles.actions}>
            <Link className={styles.primaryAction} to="/poemas">
              Explorar poemas
            </Link>
            <Link className={styles.secondaryAction} to="/novelas">
              Entrar a las novelas
            </Link>
          </div>
        </div>
        <aside className={styles.quoteCard}>
          <p>
            “La interfaz correcta no compite con la voz del autor: la enmarca, la sostiene y desaparece a
            tiempo.”
          </p>
        </aside>
      </section>

      <ContentList title="Lecturas recientes">
        {featured.map((post) => (
          <PostCard key={post.id} post={post} />
        ))}
      </ContentList>
    </div>
  );
};
