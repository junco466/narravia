import styles from '@/presentation/components/Footer/Footer.module.css';

export const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <p>Un espacio para poemas, novelas y pensamientos escritos con ritmo lento.</p>
        <p>Arquitectura desacoplada, contenido primero, UI preparada para backend.</p>
      </div>
    </footer>
  );
};
