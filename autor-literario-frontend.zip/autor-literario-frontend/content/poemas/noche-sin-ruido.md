---
title: "Noche sin ruido"
date: "2026-04-12"
type: "poema"
excerpt: "Un poema breve sobre la casa cuando todos duermen y el reloj parece pensar en voz baja."
coverQuote: "La noche no calla: apenas cambia de volumen."
seoDescription: "Poema sobre el silencio nocturno y la respiración doméstica."
---

La casa aprende otra gramática
cuando todos duermen.

La madera habla en voz mínima,
el agua recuerda su camino,
y el reloj, lejos,
parece ordenar las sombras.

Yo escribo con la lámpara cansada,
como si cada palabra
pudiera tocar apenas
la costura del silencio.

Nada ocurre,
y sin embargo
la noche trabaja.
