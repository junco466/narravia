---
title: "Manual para regresar"
date: "2026-03-18"
type: "poema"
excerpt: "Un poema sobre el retorno, la memoria y los lugares que conservan nuestra forma anterior."
coverQuote: "Regresar no siempre es volver: a veces es reconocer la herida con otro nombre."
---

No vuelvas de golpe.

Deja primero la mano
sobre la puerta,
como quien saluda un animal antiguo.

Mira cómo el pasillo
aún recuerda tu prisa.
La ventana,
tu forma de mirar la lluvia.

Después entra.
No preguntes quién fuiste.

Las casas honestas
contestan despacio.
